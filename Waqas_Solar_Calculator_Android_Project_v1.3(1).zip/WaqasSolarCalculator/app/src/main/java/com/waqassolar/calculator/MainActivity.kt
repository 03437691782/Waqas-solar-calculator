package com.waqassolar.calculator

import android.os.Bundle
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlin.math.ceil
import kotlin.math.max

data class Appliance(
    val name: String,
    val quantity: String = "1",
    val watts: String = "100",
    val hours: String = "5"
)

data class StringCheck(
    val coldVoc: Double,
    val maxSeries: Int,
    val minSeries: Int,
    val maxStringsPerMppt: Int,
    val message: String
)

data class SolarResult(
    val connectedW: Double,
    val dailyKwh: Double,
    val designLoadW: Double,
    val inverterKw: Double,
    val batteryKwh: Double,
    val batteryAh: Double,
    val systemVoltage: Int,
    val pvKw: Double,
    val panelCount: Int
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SolarApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SolarApp() {
    val context = LocalContext.current
    var urdu by remember { mutableStateOf(false) }
    var brand by remember { mutableStateOf("Knox") }
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var customerAddress by remember { mutableStateOf("") }
    var brandMenu by remember { mutableStateOf(false) }
    var battery by remember { mutableStateOf("Lithium") }
    var batteryMenu by remember { mutableStateOf(false) }
    var panelW by remember { mutableStateOf("585") }
    var backupHours by remember { mutableStateOf("5") }
    var sunHours by remember { mutableStateOf("5") }
    var simultaneity by remember { mutableStateOf("0.7") }
    // Inverter datasheet inputs (enter values from the exact model manual)
    var maxPvVoltage by remember { mutableStateOf("500") }
    var mpptMinVoltage by remember { mutableStateOf("120") }
    var mpptMaxVoltage by remember { mutableStateOf("450") }
    var maxInputCurrent by remember { mutableStateOf("15") }
    var mpptCount by remember { mutableStateOf("2") }
    // Solar module electrical data for string checks
    var moduleVoc by remember { mutableStateOf("52") }
    var moduleVmp by remember { mutableStateOf("44") }
    var moduleIsc by remember { mutableStateOf("14") }
    var moduleImp by remember { mutableStateOf("13") }
    var vocTempCoeff by remember { mutableStateOf("-0.28") }
    var minAmbientTemp by remember { mutableStateOf("0") }
    var appliances by remember {
        mutableStateOf(listOf(
            Appliance("Fans", "5", "80", "8"),
            Appliance("LED lights", "8", "15", "6"),
            Appliance("Refrigerator", "1", "200", "10"),
            Appliance("Television", "1", "100", "4")
        ))
    }
    var result by remember { mutableStateOf<SolarResult?>(null) }

    val labels = if (urdu) mapOf(
        "subtitle" to "گھر کے لوڈ سے سولر سسٹم کا ابتدائی اندازہ",
        "language" to "اردو / English",
        "appliances" to "گھر کے آلات اور لوڈ",
        "add" to "آلہ شامل کریں",
        "quantity" to "تعداد",
        "watts" to "واٹ",
        "hours" to "روزانہ گھنٹے",
        "settings" to "سسٹم سیٹنگز",
        "brand" to "انورٹر برانڈ",
        "battery" to "بیٹری کی قسم",
        "panel" to "ایک پینل کے واٹ",
        "backup" to "مطلوبہ بیک اپ گھنٹے",
        "sun" to "روزانہ مؤثر دھوپ کے گھنٹے",
        "sim" to "ایک وقت میں چلنے والے لوڈ کا تناسب (0.1 تا 1.0)",
        "calculate" to "سولر سسٹم کا حساب کریں",
        "results" to "آپ کی ابتدائی سولر رپورٹ",
        "disclaimer" to "یہ تخمینہ ہے، حتمی انسٹالیشن ڈیزائن نہیں۔ اصل آلات، موٹر اسٹارٹنگ، مقام، موسم، وائرنگ، MPPT وولٹیج/کرنٹ اور بیٹری ڈیٹا شیٹ کسی مستند سولر ٹیکنیشن سے لازماً چیک کروائیں۔"
    ) else mapOf(
        "subtitle" to "Preliminary solar sizing from your home load",
        "language" to "اردو / English",
        "appliances" to "Home appliances & load",
        "add" to "Add appliance",
        "quantity" to "Qty",
        "watts" to "Watts",
        "hours" to "Hours/day",
        "settings" to "System settings",
        "brand" to "Inverter brand",
        "battery" to "Battery type",
        "panel" to "Panel wattage (custom)",
        "backup" to "Required backup hours",
        "sun" to "Effective sun hours/day",
        "sim" to "Simultaneous load factor (0.1–1.0)",
        "calculate" to "Calculate solar system",
        "results" to "Your preliminary solar report",
        "disclaimer" to "Estimate only, not a final installation design. Have a qualified solar technician verify actual appliance data, motor starting surge, location/weather, wiring, MPPT voltage/current limits and battery datasheet before installation."
    )

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF087E68))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Waqas Solar Calculator", fontWeight = FontWeight.Bold)
                            Text(labels["subtitle"]!!, style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    actions = {
                        TextButton(onClick = { urdu = !urdu }) { Text(if (urdu) "EN" else "اردو") }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(labels["appliances"]!!, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                itemsIndexed(appliances) { index, item ->
                    ElevatedCard {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = item.name,
                                onValueChange = { v -> appliances = appliances.toMutableList().also { it[index] = item.copy(name = v) } },
                                label = { Text(if (urdu) "آلے کا نام" else "Appliance name") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                NumberField(labels["quantity"]!!, item.quantity, Modifier.weight(1f)) { v ->
                                    appliances = appliances.toMutableList().also { it[index] = item.copy(quantity = v) }
                                }
                                NumberField(labels["watts"]!!, item.watts, Modifier.weight(1f)) { v ->
                                    appliances = appliances.toMutableList().also { it[index] = item.copy(watts = v) }
                                }
                                NumberField(labels["hours"]!!, item.hours, Modifier.weight(1f)) { v ->
                                    appliances = appliances.toMutableList().also { it[index] = item.copy(hours = v) }
                                }
                            }
                            TextButton(onClick = { appliances = appliances.filterIndexed { i, _ -> i != index } }) {
                                Text(if (urdu) "حذف کریں" else "Remove")
                            }
                        }
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { appliances = appliances + Appliance("New appliance", "1", "100", "1") },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("+ ${labels["add"]}") }
                }
                item {
                    Text(if (urdu) "کسٹمر کی معلومات" else "Customer details", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = customerName, onValueChange = { customerName = it },
                        label = { Text(if (urdu) "کسٹمر کا نام" else "Customer name") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                    OutlinedTextField(
                        value = customerPhone, onValueChange = { customerPhone = it },
                        label = { Text(if (urdu) "فون نمبر" else "Phone number") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                    OutlinedTextField(
                        value = customerAddress, onValueChange = { customerAddress = it },
                        label = { Text(if (urdu) "پتہ" else "Address") },
                        modifier = Modifier.fillMaxWidth(), minLines = 2
                    )
                }
                item {
                    Text(labels["settings"]!!, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    ExposedDropdownMenuBox(expanded = brandMenu, onExpandedChange = { brandMenu = !brandMenu }) {
                        OutlinedTextField(
                            value = brand, onValueChange = {}, readOnly = true,
                            label = { Text(labels["brand"]!!) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = brandMenu, onDismissRequest = { brandMenu = false }) {
                            listOf("Knox", "Inverex", "Growatt", "Solis", "GoodWe", "Itel", "Crown", "Fronus", "Other / Generic").forEach {
                                DropdownMenuItem(text = { Text(it) }, onClick = { brand = it; brandMenu = false })
                            }
                        }
                    }
                    ExposedDropdownMenuBox(expanded = batteryMenu, onExpandedChange = { batteryMenu = !batteryMenu }) {
                        OutlinedTextField(
                            value = battery, onValueChange = {}, readOnly = true,
                            label = { Text(labels["battery"]!!) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = batteryMenu, onDismissRequest = { batteryMenu = false }) {
                            listOf("Lithium", "Lead Acid").forEach {
                                DropdownMenuItem(text = { Text(it) }, onClick = { battery = it; batteryMenu = false })
                            }
                        }
                    }
                    NumberField(labels["panel"]!!, panelW, Modifier.fillMaxWidth()) { panelW = it }
                    NumberField(labels["backup"]!!, backupHours, Modifier.fillMaxWidth()) { backupHours = it }
                    NumberField(labels["sun"]!!, sunHours, Modifier.fillMaxWidth()) { sunHours = it }
                    NumberField(labels["sim"]!!, simultaneity, Modifier.fillMaxWidth(), decimal = true) { simultaneity = it }
                    Spacer(Modifier.height(8.dp))
                    Text(if (urdu) "انورٹر کی اصل ڈیٹا شیٹ" else "Inverter datasheet values", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(if (urdu) "یہ قدریں منتخب انورٹر ماڈل کی مینول سے درج کریں۔" else "Enter these values from the exact inverter model datasheet.", style = MaterialTheme.typography.bodySmall)
                    NumberField("Maximum PV voltage (V)", maxPvVoltage, Modifier.fillMaxWidth()) { maxPvVoltage = it }
                    NumberField("MPPT minimum voltage (V)", mpptMinVoltage, Modifier.fillMaxWidth()) { mpptMinVoltage = it }
                    NumberField("MPPT maximum voltage (V)", mpptMaxVoltage, Modifier.fillMaxWidth()) { mpptMaxVoltage = it }
                    NumberField("Maximum PV input current per MPPT (A)", maxInputCurrent, Modifier.fillMaxWidth(), decimal = true) { maxInputCurrent = it }
                    NumberField("Number of independent MPPTs", mpptCount, Modifier.fillMaxWidth()) { mpptCount = it }
                    Spacer(Modifier.height(8.dp))
                    Text(if (urdu) "سولر پینل کی الیکٹریکل تفصیلات" else "Solar module electrical values", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    NumberField("Module Voc (V)", moduleVoc, Modifier.fillMaxWidth(), decimal = true) { moduleVoc = it }
                    NumberField("Module Vmp (V)", moduleVmp, Modifier.fillMaxWidth(), decimal = true) { moduleVmp = it }
                    NumberField("Module Isc (A)", moduleIsc, Modifier.fillMaxWidth(), decimal = true) { moduleIsc = it }
                    NumberField("Module Imp (A)", moduleImp, Modifier.fillMaxWidth(), decimal = true) { moduleImp = it }
                    NumberField("Voc temperature coefficient (%/°C)", vocTempCoeff, Modifier.fillMaxWidth(), decimal = true) { vocTempCoeff = it }
                    NumberField("Minimum site temperature (°C)", minAmbientTemp, Modifier.fillMaxWidth(), decimal = true) { minAmbientTemp = it }
                }
                item {
                    Button(
                        onClick = {
                            result = calculate(appliances, panelW, backupHours, sunHours, simultaneity, battery)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(labels["calculate"]!!) }
                }
                result?.let { r ->
                    item {
                        ElevatedCard {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(labels["results"]!!, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                ResultLine("Inverter brand", brand)
                                ResultLine("Connected load", "${r.connectedW.toInt()} W")
                                ResultLine("Estimated simultaneous load", "${r.designLoadW.toInt()} W")
                                ResultLine("Daily energy", "${"%.2f".format(r.dailyKwh)} kWh")
                                ResultLine("Suggested inverter", "${"%.1f".format(r.inverterKw)} kW or next suitable model")
                                ResultLine("Battery", "${"%.2f".format(r.batteryKwh)} kWh nominal")
                                ResultLine("Battery bank", "${r.systemVoltage} V • approx. ${r.batteryAh.toInt()} Ah")
                                ResultLine("PV array", "${"%.2f".format(r.pvKw)} kW")
                                ResultLine("Panels", "${r.panelCount} × ${panelW.toIntOrNull() ?: 0} W")
                                Divider()
                                Text("MPPT / String preliminary check", fontWeight = FontWeight.Bold)
                                val stringCheck = calculateStrings(
                                    r.panelCount, moduleVoc.toDoubleOrNull() ?: 0.0,
                                    moduleVmp.toDoubleOrNull() ?: 0.0,
                                    moduleIsc.toDoubleOrNull() ?: 0.0,
                                    moduleImp.toDoubleOrNull() ?: 0.0,
                                    vocTempCoeff.toDoubleOrNull() ?: 0.0,
                                    minAmbientTemp.toDoubleOrNull() ?: 0.0,
                                    maxPvVoltage.toDoubleOrNull() ?: 0.0,
                                    mpptMinVoltage.toDoubleOrNull() ?: 0.0,
                                    mpptMaxVoltage.toDoubleOrNull() ?: 0.0,
                                    maxInputCurrent.toDoubleOrNull() ?: 0.0,
                                    mpptCount.toIntOrNull() ?: 0
                                )
                                ResultLine("Cold-corrected module Voc", "${"%.1f".format(stringCheck.coldVoc)} V")
                                ResultLine("Max modules in series (voltage)", stringCheck.maxSeries.toString())
                                ResultLine("Min modules in series (MPPT)", stringCheck.minSeries.toString())
                                ResultLine("Max parallel strings / MPPT (current)", stringCheck.maxStringsPerMppt.toString())
                                Text(stringCheck.message, style = MaterialTheme.typography.bodySmall)
                                Divider()
                                Text(labels["disclaimer"]!!, style = MaterialTheme.typography.bodySmall)
                                Button(
                                    onClick = {
                                        try {
                                            val pdf = createQuotationPdf(
                                                context = context,
                                                customerName = customerName,
                                                customerPhone = customerPhone,
                                                customerAddress = customerAddress,
                                                brand = brand,
                                                batteryType = battery,
                                                panelW = panelW,
                                                result = r,
                                                stringCheck = stringCheck
                                            )
                                            val uri = FileProvider.getUriForFile(
                                                context,
                                                "com.waqassolar.calculator.fileprovider",
                                                pdf
                                            )
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = "application/pdf"
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(
                                                Intent.createChooser(shareIntent, "Share solar quotation")
                                            )
                                        } catch (e: Exception) {
                                            Toast.makeText(
                                                context,
                                                "Could not create PDF: ${e.message}",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text(if (urdu) "PDF کوٹیشن بنائیں / شیئر کریں" else "Generate & Share PDF Quotation") }
                            }
                        }
                    }
                }
                item {
                    Text(
                        "Version 1.2 • Waqas Solar Calculator",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun NumberField(label: String, value: String, modifier: Modifier = Modifier, decimal: Boolean = false, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { s -> onValue(s.filter { it.isDigit() || (decimal && it == '.') }) },
        label = { Text(label) },
        modifier = modifier,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else KeyboardType.Number)
    )
}

@Composable
fun ResultLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
    }
}

fun calculate(
    appliances: List<Appliance>,
    panelWText: String,
    backupText: String,
    sunText: String,
    simultaneityText: String,
    batteryType: String
): SolarResult {
    val connected = appliances.sumOf {
        (it.quantity.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0) *
        (it.watts.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    }
    val dailyKwh = appliances.sumOf {
        (it.quantity.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0) *
        (it.watts.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0) *
        (it.hours.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 24.0)
    } / 1000.0
    val factor = (simultaneityText.toDoubleOrNull() ?: 0.7).coerceIn(0.1, 1.0)
    val designLoad = connected * factor
    val inverterKw = max(1.0, designLoad * 1.25 / 1000.0)
    val backup = (backupText.toDoubleOrNull() ?: 5.0).coerceIn(0.0, 24.0)
    val dod = if (batteryType == "Lithium") 0.80 else 0.50
    val batteryEfficiency = if (batteryType == "Lithium") 0.92 else 0.85
    val batteryKwh = (designLoad / 1000.0 * backup / (dod * batteryEfficiency)).coerceAtLeast(0.0)
    val voltage = if (inverterKw <= 3.0) 24 else 48
    val batteryAh = batteryKwh * 1000.0 / voltage
    val sun = (sunText.toDoubleOrNull() ?: 5.0).coerceIn(1.0, 10.0)
    val pvKw = dailyKwh / (sun * 0.75)
    val panelW = (panelWText.toDoubleOrNull() ?: 585.0).coerceAtLeast(1.0)
    val count = ceil(pvKw * 1000.0 / panelW).toInt()
    return SolarResult(connected, dailyKwh, designLoad, inverterKw, batteryKwh, batteryAh, voltage, pvKw, count)
}


fun calculateStrings(
    panelCount: Int, voc: Double, vmp: Double, isc: Double, imp: Double,
    vocCoeffPercent: Double, minTempC: Double, maxPvV: Double,
    mpptMinV: Double, mpptMaxV: Double, maxInputA: Double, mpptCount: Int
): StringCheck {
    if (panelCount <= 0 || voc <= 0 || vmp <= 0 || isc <= 0 || imp <= 0 ||
        maxPvV <= 0 || mpptMinV <= 0 || mpptMaxV <= 0 || maxInputA <= 0 || mpptCount <= 0) {
        return StringCheck(0.0, 0, 0, 0, "Enter valid positive inverter and module datasheet values to check strings.")
    }
    // Approximate cold Voc correction from STC (25°C). Verify coefficient convention in module datasheet.
    val coldVoc = voc * (1.0 + (vocCoeffPercent / 100.0) * (minTempC - 25.0))
    val safeVoc = if (coldVoc > 0) coldVoc else voc
    val maxByAbsolute = kotlin.math.floor(maxPvV / safeVoc).toInt()
    val maxByMppt = kotlin.math.floor(mpptMaxV / vmp).toInt()
    val maxSeries = minOf(maxByAbsolute, maxByMppt)
    val minSeries = ceil(mpptMinV / vmp).toInt()
    // Use module Isc with a 1.25 screening factor against the entered per-MPPT input-current limit.
    val maxStrings = kotlin.math.floor(maxInputA / (isc * 1.25)).toInt()
    val message = when {
        minSeries > maxSeries || maxSeries < 1 -> "No valid series length from the entered voltage limits. Recheck exact inverter/module datasheets and coldest design temperature."
        maxStrings < 1 -> "One parallel string may exceed the entered per-MPPT current screening limit. Do not connect until verified against inverter Isc and operating-current limits."
        else -> "Voltage/current screening only. Check total PV power, per-MPPT allocation, connector/string input limits, inverter maximum short-circuit current and local design temperature before installation. Estimated maximum parallel strings across all MPPTs: ${maxStrings * mpptCount}."
    }
    return StringCheck(safeVoc, maxSeries, minSeries, maxStrings, message)
}


fun createQuotationPdf(
    context: android.content.Context,
    customerName: String,
    customerPhone: String,
    customerAddress: String,
    brand: String,
    batteryType: String,
    panelW: String,
    result: SolarResult,
    stringCheck: StringCheck
): File {
    val document = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = document.startPage(pageInfo)
    val canvas: Canvas = page.canvas
    val titlePaint = Paint().apply { textSize = 22f; isFakeBoldText = true; color = android.graphics.Color.rgb(8, 126, 104) }
    val headingPaint = Paint().apply { textSize = 14f; isFakeBoldText = true; color = android.graphics.Color.BLACK }
    val textPaint = Paint().apply { textSize = 11f; color = android.graphics.Color.DKGRAY }
    val smallPaint = Paint().apply { textSize = 9f; color = android.graphics.Color.GRAY }
    var y = 42f

    // Simple original solar brand mark drawn directly into the PDF (no external logo file required).
    val green = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(8, 126, 104)
        style = Paint.Style.FILL
    }
    val yellow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(245, 184, 35)
        style = Paint.Style.FILL
    }
    val blue = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(28, 91, 160)
        style = Paint.Style.FILL
    }
    canvas.drawCircle(62f, 57f, 22f, yellow)
    canvas.drawRoundRect(47f, 58f, 83f, 78f, 3f, 3f, blue)
    for (i in 1..2) {
        canvas.drawLine(47f + i * 12f, 58f, 47f + i * 12f, 78f, Paint().apply {
            color = android.graphics.Color.WHITE
            strokeWidth = 1.2f
        })
    }
    canvas.drawLine(47f, 68f, 83f, 68f, Paint().apply {
        color = android.graphics.Color.WHITE
        strokeWidth = 1.2f
    })
    canvas.drawArc(39f, 68f, 88f, 91f, 5f, 170f, false, green.apply { style = Paint.Style.STROKE; strokeWidth = 4f })

    canvas.drawText("WAQAS SOLAR CALCULATOR", 105f, y + 12f, titlePaint)
    y += 34f
    canvas.drawText("Solar System Estimate & Quotation", 105f, y + 8f, headingPaint)
    y += 30f
    canvas.drawText("Muhammad Waqas | Solar Technician", 105f, y, textPaint)
    y += 16f
    canvas.drawText("03437691782  |  03216862395", 105f, y, textPaint)
    y += 16f
    canvas.drawText("District Toba Tek Singh, Pakistan", 105f, y, textPaint)
    y += 24f

    fun line(label: String, value: String) {
        canvas.drawText(label, 42f, y, textPaint)
        canvas.drawText(value.take(58), 270f, y, textPaint)
        y += 20f
    }

    canvas.drawText("CUSTOMER DETAILS", 40f, y, headingPaint); y += 22f
    line("Customer name", customerName.ifBlank { "Not provided" })
    line("Phone", customerPhone.ifBlank { "Not provided" })
    line("Address", customerAddress.ifBlank { "Not provided" })
    y += 8f
    canvas.drawText("SYSTEM SUMMARY", 40f, y, headingPaint); y += 22f
    line("Inverter brand", brand)
    line("Connected load", "${result.connectedW.toInt()} W")
    line("Estimated simultaneous load", "${result.designLoadW.toInt()} W")
    line("Daily energy estimate", "${"%.2f".format(result.dailyKwh)} kWh/day")
    line("Suggested inverter size", "${"%.1f".format(result.inverterKw)} kW (verify model)")
    line("Battery chemistry", batteryType)
    line("Estimated nominal battery", "${"%.2f".format(result.batteryKwh)} kWh")
    line("Estimated battery bank", "${result.systemVoltage} V / ${result.batteryAh.toInt()} Ah")
    line("Estimated PV array", "${"%.2f".format(result.pvKw)} kW")
    line("Panel quantity", "${result.panelCount} x ${panelW} W")
    y += 8f
    canvas.drawText("PRELIMINARY MPPT / STRING SCREENING", 40f, y, headingPaint); y += 22f
    line("Cold-corrected module Voc", "${"%.1f".format(stringCheck.coldVoc)} V")
    line("Max modules in series", stringCheck.maxSeries.toString())
    line("Min modules in series", stringCheck.minSeries.toString())
    line("Max parallel strings / MPPT", stringCheck.maxStringsPerMppt.toString())
    y += 8f
    canvas.drawText("IMPORTANT DESIGN NOTES", 40f, y, headingPaint); y += 18f
    val notes = listOf(
        "This document is a preliminary estimate, not a final electrical design or firm-price quotation.",
        "Confirm exact inverter and module datasheets, cold-temperature Voc, MPPT current limits,",
        "PV input power, string allocation, battery BMS compatibility, surge loads, cable sizing,",
        "protection devices, earthing and local site conditions before purchase or installation.",
        "Battery Ah and inverter size are approximate screening values and require model-specific review."
    )
    notes.forEach {
        canvas.drawText(it, 42f, y, smallPaint)
        y += 14f
    }
    y += 18f
    canvas.drawText("Prepared by: Muhammad Waqas | Solar Technician", 40f, y, headingPaint)
    y += 16f
    canvas.drawText("Contact: 03437691782 / 03216862395", 40f, y, textPaint)
    y += 16f
    canvas.drawText("Location: District Toba Tek Singh, Pakistan", 40f, y, textPaint)
    y += 18f
    canvas.drawText("Generated from user-entered values. Prices and taxes are not included.", 40f, y, smallPaint)

    document.finishPage(page)
    val directory = File(context.getExternalFilesDir(null), "quotations")
    if (!directory.exists()) directory.mkdirs()
    val safeName = customerName.trim().replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "Customer" }
    val file = File(directory, "Waqas_Solar_Quotation_${safeName}_${System.currentTimeMillis()}.pdf")
    file.outputStream().use { document.writeTo(it) }
    document.close()
    return file
}
