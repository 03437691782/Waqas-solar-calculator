# Waqas Solar Calculator — Android MVP 1.2

Kotlin + Jetpack Compose Android Studio project.

## Included
- Urdu/English app labels
- Editable home appliance list: quantity, watts and hours/day
- Inverter brands: Knox, Inverex, Growatt, Solis, GoodWe, Itel, Crown, Fronus, Other / Generic
- Lithium and Lead Acid battery selection
- Custom solar panel wattage
- Backup hours, effective sun hours and simultaneous load factor
- Inverter datasheet inputs: maximum PV voltage, MPPT voltage range, PV input current and MPPT count
- Module electrical inputs: Voc, Vmp, Isc, Imp, Voc temperature coefficient and minimum site temperature
- Preliminary MPPT/string voltage and current screening
- Customer name, phone and address
- Generate and share a PDF solar estimate/quotation with a built-in vector solar logo, technician name, saved business phone numbers and district location

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK 35 if requested.
3. Run on an Android phone/emulator.
4. Build APK using Build > Build Bundle(s) / APK(s) > Build APK(s).

## Business branding in PDF
The PDF header includes an original solar icon and the technician details: Muhammad Waqas, Solar Technician; 03437691782 / 03216862395; District Toba Tek Singh, Pakistan. These details are prefilled as supplied previously and can be edited in source code if needed.

## Engineering limitations
This app is a preliminary estimator, not a certified electrical design package. Battery capacity, inverter size and PV size use simplified assumptions. The string checker is only a screening aid and does not fully validate inverter model limits, PV power, per-MPPT string allocation, connectors, temperature extremes, battery BMS compatibility, protection, cable sizing or earthing. The generated PDF is an estimate, not a priced or binding quotation. Verify all equipment datasheets and installation design with a qualified solar professional.
